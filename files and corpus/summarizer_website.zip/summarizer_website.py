from flask import Flask
from flask import render_template
from flask import request
from lexrank import summarize

app = Flask(__name__)

DEFAULT_MC_ITERS = 3
DEFAULT_NRES = 10 # Number of sentences in result. Changeable?
DEFAULT_NART = 2 # Number of articles to consider. Changeable?

@app.route('/wiki/', methods=['POST', 'GET'])
def processquery():
    # These variables must be set to present the page
    summary = None
    query = None
    twocolumns = None
    usemc = None
    useheuristics = None
    lexrankversion = None
    nresults = 10
    
    if request.method == 'POST':
        query = request.form['query']
        lexrankversion = request.form['lexrankversion']
        twocolumns = lexrankversion == 'lrboth'
        useheuristics = 'heuristics' in request.form
        usemc = 'montecarlo' in request.form
        nresults = int(request.form['nresults'])
       
        if lexrankversion == 'lrv1' or lexrankversion == 'lrboth':
            print('lvr1 1')
            print(nresults)
            success_v1, summarylist_v1 = summarize(query.split(), 
                nres=nresults, nart=DEFAULT_NART, lexrankversion=1, 
                montecarlo=DEFAULT_MC_ITERS if usemc else None, 
                heuristics=useheuristics)
            print('lvr1 2')
            print(success_v1, summarylist_v1)
            summary_v1 = '. '.join(summarylist_v1) + '.'
            print('lvr1 3')
            
        if lexrankversion == 'lrv2' or lexrankversion == 'lrboth':
            print('lvr2 1')
            success_v2, summarylist_v2 = summarize(query.split(), 
                nres=nresults, nart=DEFAULT_NART, lexrankversion=2, 
                montecarlo=DEFAULT_MC_ITERS if usemc else None, 
                heuristics=useheuristics)
            print('lvr2 2')
            print(success_v2, summarylist_v2)
            summary_v2 = ' '.join(summarylist_v2)
            print('lvr2 3')
            
        if (lexrankversion == 'lrv1' and success_v1) or \
           (lexrankversion == 'lrv2' and success_v2) or \
           (lexrankversion == 'lrboth' and success_v1 and success_v2):
            print('sucess 1')
            if lexrankversion == 'lrv1':
                summary = summary_v1
            elif lexrankversion == 'lrv2':
                summary = summary_v2
            elif lexrankversion == 'lrboth':
                summary = [summary_v1, summary_v2]
            print('sucess 2')
            
        else:
            print('not sucess 1')
            error = "Problem disambiguating the query. Try adding more information." 
            print(len(summarylist_v1))
            if len(summarylist_v1) == 1:
                print(summarylist_v1)
                error_info = summarylist_v1[0]
            print('not sucess 2')
            return render_template('layout.html', query=query, error=error, 
                error_info=error_info, nresults=nresults)
    
    print(query, summary, usemc,useheuristics, lexrankversion, twocolumns)
    return render_template('layout.html', query=query, msg=summary, usemc=usemc, 
        useheuristics=useheuristics, lexrankversion=lexrankversion, 
        twocolumns=twocolumns, nresults=nresults)
    
if __name__ == '__main__':
    app.run(host='0.0.0.0')
